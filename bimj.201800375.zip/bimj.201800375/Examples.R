################################################################################
## Negera Wakgari Deresa - KU Leuven - negerawakgari.deresa@kuleuven.be
## (last update : May 08, 2019) 
## Flexible parametric model for survival data subject to dependent censoring.
#################################################################################

source('Functions-FPM.R')    # Please load these functions before you run the code
library(tmvtnorm)
library(mvtnorm)
library(nloptr)
library(MASS)
library(xtable)
library(survival)
library(pbivnorm)
library(optimr)
library(numDeriv)
library(matrixcalc)
library(copula)


# Simulation results in Section 5.1

SimulationCI = function(n,nsim,iseed)
{
  sum = c()
  sum1 = c()
  lambda = c(0,0.5,1.5)
  
  for (j in lambda)
  {
    results = c()
    results1 = c()
    alp = j
    per=0
    
    parN = list(beta=c(2,1.2,1.5),eta=c(2.5,0.5,1),sd=c(1,1.5,0.75,alp))    #45% censoring
    
    #parN = list(beta=c(3.25,-0.45,1.2),eta=c(3.5,0.6,1),sd=c(1,1.5,0.75,alp))  #25 % censoring
    
    
    for (i in 1:nsim)
    {
      
      data = dat.sim.reg(n,parN,iseed+i)
      
      Y = data[,1]
      Delta = data[,2]
      M = data[,3:5]
      
      per=per+table(Delta)[1]
       
      init = c(1.5,1,1.4,2.2,0.4,0.9,1,0.7,0.6,alp) #initial 45 % censoring
      #init = c(2.8,-0.3,1,3.1,0.5,1.1,1,1.3,0.6,alp)  #initial 25 % censoring
      init2 = init[-9]
      
      test = parhat
      if (test[9]>=0.99) 
      {
        parhat[9] = test[9]-0.01 
      }
      if (test[9]<=-0.99)
      {
        parhat[9] = test[9]+0.01 
      }
      
      H = hessian(LikF,parhat,Y=Y,Delta=Delta,M=M,method="Richardson",method.args=list(eps=1e-4, d=0.001, zer.tol=sqrt(.Machine$double.eps/7e-7), r=6, v=2, show.details=FALSE)) 
      
      H = ginv(H, tol = sqrt(.Machine$double.eps))
      se = sqrt(abs(diag(H)))
      
      #Delta method variance
      
      se_s1 = 1/parhat[7]*se[7]
      se_s2 = 1/parhat[8]*se[8]
      
      # Conf. interval for transf. sigma's
      st1_l = log(parhat[7])-1.96*se_s1 ;  st1_u = log(parhat[7])+1.96*se_s1  #log sigma scale
      st2_l = log(parhat[8])-1.96*se_s2 ;  st2_u = log(parhat[8])+1.96*se_s2 
      
      # Back transfrom;
      s1_l = exp(st1_l); s1_u = exp(st1_u); s2_l = exp(st2_l); s2_u = exp(st2_u) #sigma scale
      
      # Confidence interval for rho
      
      zt = 0.5*(log((1+parhat[9])/(1-parhat[9])))     #Fisher's z transform
      se_z = (1/(1-parhat[9]^2))*se[9]
      zt_l = zt-1.96*(se_z)
      zt_u = zt+1.96*(se_z)
      
      #back transform
      
      r_l = (exp(2*zt_l)-1)/(exp(2*zt_l)+1)      #back transform to rho scale
      r_u = (exp(2*zt_u)-1)/(exp(2*zt_u)+1)
      
      EC1 = cbind(matrix(c(parhat[1:6]-1.96*(se[1:6]),s1_l,s2_l,r_l,parhat[10]-1.96*(se[10])),ncol=1),matrix(c(parhat[1:6]+1.96*(se[1:6]),s1_u,s2_u,r_u,parhat[10]+1.96*(se[10])), ncol=1))
      
      parhat1 = nloptr(x0=c(init2),eval_f=LikI,Y=Y,Delta=Delta,M=M,lb=c(-Inf,-Inf,-Inf,-Inf,-Inf,-Inf,1e-05,1e-5,-0.5),ub=c(Inf,Inf,Inf,Inf,Inf,Inf,Inf,Inf,2),
                       eval_g_ineq=NULL,opts = list(algorithm = "NLOPT_LN_BOBYQA","ftol_abs"=1.0e-30,"maxeval"=100000,"xtol_abs"=rep(1.0e-30)))$solution
      
      H1 = hessian(LikI,parhat1,Y=Y,Delta=Delta,M=M,method="Richardson",method.args=list(eps=1e-4, d=0.01, zer.tol=sqrt(.Machine$double.eps/7e-7), r=6, v=2, show.details=FALSE)) 
      H1 = solve(H1)
      se1 = sqrt(abs(diag(H1)));
      
      #Delta method variance
      
      t_s1 = 1/parhat1[7]*se1[7]
      t_s2 = 1/parhat1[8]*se1[8]
      
      # Conf. interval for transf. sigma's
      ms1_l = log(parhat1[7])-1.96*t_s1 ;  ms1_u = log(parhat1[7])+1.96*t_s1  #log sigma scale
      ms2_l = log(parhat1[8])-1.96*t_s2 ;  ms2_u = log(parhat1[8])+1.96*t_s2 
      
      # Back transfrom;
      S1_l = exp(ms1_l); S1_u = exp(ms1_u); S2_l = exp(ms2_l); S2_u = exp(ms2_u) #sigma scale
      
      EC2 = cbind(matrix(c(parhat1[1:6]-1.96*(se1)[1:6],S1_l,S2_l,parhat1[9]-1.96*(se1[9])),ncol=1), matrix(c(parhat1[1:6]+1.96*(se1[1:6]),S1_u,S2_u,parhat1[9]+1.96*(se1[9])),ncol=1))  #Naive CI
      
      results = rbind(results,c(parhat,se,c(t(EC1))))
      results1 = rbind(results1,c(parhat1,se1,c(t(EC2))))
    }
    
    print(per/(n*nsim))     #percentage of censoring
    
    ## For dependent model
    
    par0 = c(parN[[1]],parN[[2]],parN[[3]])
    par0m = matrix(par0,nsim,10,byrow=TRUE)
    
    Bias = apply(results[,1:10]-par0m,2,mean)
    ESE = apply(results[,1:10],2,sd)
    MSD  = apply(results[,11:20],2, mean)
    RMSE = sqrt(apply((results[,1:10]-par0m)^2,2,mean))
    
    CP = rep(0,10)
    datacp = results[,21:40]
    for(i in 1:10)
    {
      index=c(2*i-1,2*i)
      CP[i]=sum(datacp[,index[1]]<=par0[i] & datacp[,index[2]]>=par0[i])/nsim
    } 
    
    summary = cbind(Bias,ESE,MSD,RMSE,CP) 
    
    ## For independent model
    
    par0 = c(parN[[1]],parN[[2]],parN[[3]])
    par0 = par0[-9]
    par0m = matrix(par0,nsim,9,byrow=TRUE)
    
    Bias = apply(results1[,1:9]-par0m,2,mean)
    ESE = apply(results1[,1:9],2,sd)
    MSD  = apply(results1[,10:18],2, mean)
    RMSE = sqrt(apply((results1[,1:9]-par0m)^2,2,mean))
    
    
    CP = rep(0,9)
    datacp = results1[,19:36]
    for(i in 1:9){
      index = c(2*i-1,2*i)
      CP[i] = sum(datacp[,index[1]]<=par0[i] & datacp[,index[2]]>=par0[i])/nsim
    } 
    
    summary1 = cbind(Bias,ESE,MSD,RMSE,CP) 
    
    sum = cbind(sum,summary)
    sum1 = cbind(sum1,summary1)
  }
  
  ##Write out results of dependent model
  
  colnames(sum) = c("Bias","EmpSD","ESD","RMSE","CPE","Bias","EmpSD","ESD","RMSE","CPE","Bias","EmpSD","ESD","RMSE","CPE")
  rownames(sum) = c("Beta0","Beta1", "Beta2","Eta0","Eta1","Eta2","Sigma1","sigma2","rho","alpha")
  xtab = xtable(sum)
  digits(xtab) = rep(3,16)
  header= c("sample size",n)
  addtorow = list()
  addtorow$pos = list(-1)
  addtorow$command = paste0(paste0('& \\multicolumn{1}{c}{', header, '}', collapse=''), '\\\\')
  
  print.xtable(xtab,file=paste0("newdep25_",n,".txt"),add.to.row=addtorow,append=TRUE,table.placement="!")
  print(xtab, add.to.row=addtorow, include.colnames=TRUE)
  
  ##Write out results of independent model
  
  colnames(sum1)=c("Bias","EmpSD","ESD","RMSE","CPE","Bias","EmpSD","ESD","RMSE","CPE","Bias","EmpSD","ESD","RMSE","CPE")
  rownames(sum1)=c("Beta0","Beta1", "Beta2","Eta0","Eta1","Eta2","Sigma1","sigma2","alpha")
  xtab1 = xtable(sum1)
  digits(xtab1) = rep(3,16)
  header= c("sample size",n)
  addtorow = list()
  addtorow$pos = list(-1)
  addtorow$command = paste0(paste0('& \\multicolumn{1}{c}{', header, '}', collapse=''), '\\\\')
  
  print.xtable(xtab1,file=paste0("newind25_",n,".txt"),add.to.row=addtorow,append=TRUE,table.placement="!")
  print(xtab1, add.to.row=addtorow, include.colnames=TRUE)
  
}


#Producing tables 1-2 and 7 and 8

samsize= c(300,600)
lambda = c(0,0.5,1.5)

for(l in samsize)
{
  nsim = 2000
  myseed = 684132
  SimulationCI(l,nsim,myseed)
}




#############################
#Copula model--Section 5.2
############################


CopulaM = function(rho,C){
  
  #Specify the setting here
  
  n = 500;
  nsim = 1000
  iseed = 684132
  results = c()
  results1 = c()
    
  for(i in 1:nsim)
  {
    par = list(beta = c(0,0.75),eta = c(0,1),sd = c(1,1,0.75,0.5,5))     #45 % t-copula
    data = dat.sim.competitors(n,par,iseed+i,C)
    Y = data[,1]
    d = data[,2]
    M = data[,4]
    
    init = c(0.4,0.7,0.35);
 
  
    parhat = optim(init,LikCopula,Y=Y,d=d,M=M,W=M,rho1 = rho,gr = NULL,method = "Nelder-Mead",lower=-Inf,upper=Inf,control=c(trace=0))$par; #nonparametric
    
    init1 = c(0.4,0.65,0.45,0.30);
    
    optPar= optim(init1,LikProposed,Y=Y,Delta=d,M=M,gr = NULL,method = "Nelder-Mead",lower=-Inf,upper=Inf,control=c(trace=0))$par; #parametric method
    
    results = rbind(results,parhat)
    results1 = rbind(results1,optPar)
  }
  dat = cbind(results,results1)
  return(dat)
}


#Producing Table - 4 in revised paper


mod = c(1,2,3,4,5)  # 1 = normal, 2 = t-copula, 3 = Frank copula; 4 = Gumbel Copula; 5 = t -margins
rho = 0.75  # rho = 0.75 correctly specified; rho = 0.45, misspecified (please replace 0.75 by 0.45 when you like to produce results under 0.45)
nsim = 1000
par0 = c(0.75,1,0.5)
par1 = c(0.75,1,rho,0.5)
par0m = matrix(par0,nsim,3,byrow = TRUE)
par0m1 = matrix(par1,nsim,4,byrow = TRUE)


for (j in mod){
  out = CopulaM(rho,j)
  
  #Copula model
  Bias = apply(out[,1:3]-par0m,2,mean)
  ESE = apply(out[,1:3],2,sd)
  RMSE = sqrt(apply((out[,1:3]-par0m)^2,2,mean))
  temp = cbind(Bias,ESE,RMSE)
  row.names(temp) = c("beta","eta","theta")
  print(j)
  print(temp)
  
  #proposed model
  Bias1 = apply(out[,4:7]-par0m1,2,mean)
  ESE1 = apply(out[,4:7],2,sd)
  RMSE1 = sqrt(apply((out[,4:7]-par0m1)^2,2,mean))
  temp1 = cbind(Bias1,ESE1,RMSE1)
  row.names(temp1) = c("beta","eta","rho","theta")
  print(j)
  print(temp1)
}


#########################################
#Goodness-of-fit simulations--Section 5.3
#########################################


GOF = function(n,mod) {
  iseed = 684132
  results = c()
  
  for(i in 1:500){
      
      if(mod==1){
        par = list(beta = c(2.2,1,1.7),eta = c(2.7,0.5,1.2),sd = c(1,1.5,0.70,0.5)) #45 %
        data = dat.sim.reg(n,par,iseed+i) # normal model
      }
      else if(mod==2){
        par = list(beta = c(2.2,1,1.7),eta = c(2.7,0.5,1.2),sd = c(1,1.5,0.70,10,0.5)) #t-copula, 45 %
        data = dat.sim.reg1(n,par,iseed+i) # t-model
      }
      else if(mod==3){
        par = list(beta = c(2.2,1,1.7),eta = c(2.7,0.5,1.2),sd = c(1,1.5,0.70,5,0.5)) #t-copula, 45 %
        data = dat.sim.reg1(n,par,iseed+i) # t-model
      }
      
      Y = data[,1]
      Delta = data[,2]
      M = data[,3:5]
      W = M
      k = ncol(M)
      l = 2*k ; u1 = l+1;u2 = l+3
      v = k+1
      
      # dependent Censoring model 
      
      lb = c(rep(-Inf,l),1e-02,1e-02,-1,-0.5)
      ub = c(rep(Inf,(l+2)),1,2)
      
      init = c(1.6,0.7,1.3,2.2,0.3,1,0.7,1.1,0.25,0.3)
      
      parhat = nloptr(x0=init,eval_f=LikF,Y=Y,Delta=Delta,M=M,lb=lb,ub=ub,eval_g_ineq=NULL,opts = list(algorithm = "NLOPT_LN_BOBYQA","ftol_abs"=1.0e-30,"maxeval"=100000,"xtol_abs"=rep(1.0e-30)))$solution
      
      Z0 = YJtrans(Y,parhat[(l+4)])
      
      #Empirical distr.
      
      OCd = rep(0,n)
      
      for (i in 1:n){
        ob = Z0[i]
        T1 = (ob-M%*% parhat[1:k])/parhat[(l+1)]
        T2 = (ob-W%*% parhat[v:l])/parhat[(l+2)]
        
        X = cbind(T1,T2)
        OCd[i] = sum(pnorm(T1)+pnorm(T2)-pbivnorm(X,rho= parhat[(l+3)]))/n
      }
      
      ord = 1:n
      Ecf = (ord-1)/n
      OCf = OCd[order(OCd)]
      w = rep(0,n)
      w[1] = OCf[1]
      w[2:n] = OCf[2:n]-OCf[1:(n-1)]
      
      # Compute test distribution
      
      CVM = sum((Ecf-OCf)^2*w)*n   # Cramer-Von-Mises
      
      
      B = 500 # bootstrap sample
      
      CVMb = rep(0,B)
      for(b in 1:B)
      {
        set.seed(212367+b)
        beta = parhat[1:k]
        eta = parhat[v:l]
        sd = parhat[u1:u2]
        alp = parhat[(l+4)]
        mu = c(0,0)
        sigma = matrix(c(sd[1]^2,sd[1]*sd[2]*sd[3], sd[1]*sd[2]*sd[3], sd[2]^2),ncol=2)
        err = mvrnorm(n, mu = mu , Sigma = sigma)
        err1 = err[,1] 
        err2 = err[,2]
        T1 = M%*%beta+err1                   
        C = W%*%eta+err2
        Y1 = pmin(T1,C)
        d1 = as.numeric(Y1==T1)
        Y1 = IYJtrans(Y1,alp)
        
        init1 = c(beta,eta,sd[1],sd[2],sd[3],alp)
        
        parhat.star = nloptr(x0=init1,eval_f=LikR,Y=Y1,Delta=d1,M=M,Z=W,lb=lb,ub=ub, eval_g_ineq=NULL,opts = list(algorithm = "NLOPT_LN_BOBYQA","ftol_abs"=1.0e-30,"maxeval"=100000,"xtol_abs"=rep(1.0e-30)))$solution
        
        
        z = YJtrans(Y1,parhat.star[(l+4)])
        
        
        #Calculate the distribution of minimum under assumed model.
        
        Ocdf = rep(0,n)
        
        for (i in 1:n){
          ob = z[i]
          T1 = (ob-M%*% parhat.star[1:k])/parhat.star[(l+1)]
          T2 = (ob-W%*% parhat.star[v:l])/parhat.star[(l+2)]
          
          X = cbind(T1,T2)
          Ocdf[i] = sum(pnorm(T1)+pnorm(T2)-pbivnorm(X,rho= parhat.star[(l+3)]))/n
        }
        
        ord = 1:n
        Ecf = (ord-1)/n
        
        # Compute bootstrapped test;
        
        Ocdf = Ocdf[order(Ocdf)]
        w1 = rep(0,n)
        w1[1] = Ocdf[1]
        w1[2:n] = Ocdf[2:n]-Ocdf[1:(n-1)]
        
        # Compute test distribution
        
        CVMb[b] = sum((Ecf-Ocdf)^2*w1)*n   # Cramer-Von-Mises
      }
      count1 = sum(CVM>quantile(CVMb,prob=0.9))
      count2 = sum(CVM>quantile(CVMb,prob=0.95))
      
      CVb = mean(CVMb)
      temp = c(CVM,CVb,count1,count2)
      
      results = rbind(results,temp)
  }
  return(results)
}



#Producing Table-5

model = c(1,2,3) # 1 = normal, 2 =  t with df = 10, 3 = t with df = 5
samplesize = c(300,500)

output = c()
for (l in samplesize){
  for (j in  model){
  Gof_results = GOF(l,j)
  m1 = length(Gof_results[,1])
  mean = apply(Gof_results[,1:2], 2, mean) # empirical mean
  alp1_0.1 = sum(Gof_results[,3])/m1    # 90\% CI
  alp1_0.05 = sum(Gof_results[,4])/m1  # 95\% CI
  temp = c(mean,alp1_0.05,alp1_0.1)
  output = rbind(output,temp)
  }
}

rownames(output) = c("n300-1","n300-2","n300-3","n600-1","n600-2","n600-3")
colnames(output) = c("mean1","mean2","5% Rej.","10% Rej.")

# The estimated means, 90\% and 95\% rejection probabilities

output   # Table--5



## The End
