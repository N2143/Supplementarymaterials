#################################################################################
## Negera Wakgari Deresa - KU Leuven - negerawakgari.deresa@kuleuven.be
## (last update : March 06, 2019) 
## Flexible parametric model for survival data subject to dependent censoring
##################################################################################


##LIST OF COMMON FUNCTIONS 

slog = function(y)   ## Log-transformation
{ 
  sy = (y>0)*y+(y<=0)*1 # sy>0
  return(log(sy)) 
} 

spower = function(y,pw) 
{ 
  sy = (y>0)*y+(y<=0)*1  ## sy>0
  return(sy^pw) 
} 

YJtrans = function(y,theta) # Yeo-Johnson transformation 
{ 
  sg = y>=0 
  if (theta==0) {temp = slog(y+1)*sg+(1-sg)*(0.5-0.5*(y-1)^2)} 
  if (theta==2) {temp = sg*(-0.5+0.5*(y+1)^2)-slog(-y+1)*(1-sg)} 
  if ((theta!=0) & (theta!=2)) {temp = 
    sg*(spower(y+1,theta)-1)/theta+(1-sg)*(1-spower(-y+1,2-theta))/(2-theta)} 
  return(temp) 
} 

IYJtrans = function(y,theta) # Inverse of Yeo-Johnson transformation 
{ 
  sg = y>=0 
  if (theta==0) {temp =(exp(y)-1)*sg+(1-sg)*(1-spower(-2*y+1,0.5))} 
  if (theta==2) {temp = sg*(-1+spower(2*y+1,0.5))+(1-exp(-y))*(1-sg)} 
  if ((theta!=0) & (theta!=2)) {temp = 
    sg*(spower(abs(theta)*y+1,1/theta)-1)+(1-sg)*(1-spower(1-(2-theta)*y,1/(2-theta)))} 
  return(temp) 
} 

DYJtrans = function(y,theta) # Derivative of Yeo-Johnson transformation 
{ 
  sg = y>=0 
  temp = spower(y+1,theta-1)*sg+spower(-y+1,1-theta)*(1-sg) 
  return(temp) 
} 


## Data Simulating function

dat.sim.reg = function(n,par,iseed){
  
  set.seed(iseed)
  beta = par[[1]]
  eta = par[[2]]
  sd = par[[3]]
  
  mu = c(0,0)
  sigma = matrix(c(sd[1]^2,sd[1]*sd[2]*sd[3], sd[1]*sd[2]*sd[3], sd[2]^2),ncol=2)
  err = mvrnorm(n, mu =mu , Sigma=sigma)
  
  err1 = err[,1]
  err2 = err[,2]
  
  x0 = rep(1,n)
  x1 = rbinom(n,1,0.5)
  
  x2= runif(n,-1,1)
  #x2 = x2^2
  
  M = matrix(c(x0,x1,x2),ncol=3,nrow=n)   # data matrix
  T = M%*%beta+err1
  C = M%*%eta+err2
  
  Y = pmin(T,C)
  d1 = as.numeric(Y==T)
  Y = IYJtrans(Y,sd[4])
  data = cbind(Y,d1,M)
  return(data)
}


##Likelihoods

LikF = function(par,Y,Delta,M){ #Joint model with dependent censoring
  k = ncol(M)
  l = 2*k
  v = k+1
  beta = par[1:k]
  eta = par[v:l]
  sigma1 = par[l+1]
  sigma2 = par[l+2]
  rho = par[l+3]
  alp1 = par[l+4]
  
  transY = YJtrans(Y,alp1)
  DtransY = DYJtrans(Y,alp1)
  
  z1 = (transY-(M%*%beta))/sigma1
  z2 = ((1-rho*sigma2/sigma1)*transY-(M%*%eta-rho*(sigma2/sigma1)*M%*%beta))/(sigma2*(1-rho^2)^0.5)
  z3 = (transY-(M%*%eta))/sigma2
  z4 = ((1-rho*sigma1/sigma2)*transY-(M%*%beta-rho*(sigma1/sigma2)*M%*%eta))/(sigma1*(1-rho^2)^0.5)
  tot = ((1/sigma1)*dnorm(z1)*(1-pnorm(z2)))^Delta*((1/sigma2)*dnorm(z3)*(1-pnorm(z4)))^(1-Delta)*DtransY
  p1 = pmax(tot,1e-100)
  Logn = sum(log(p1)); 
  return(-Logn)
}



LikI = function(par,Y,Delta,M){ #Independence model assumption
  k = ncol(M)
  l = 2*k
  v = k+1
  beta = par[1:k]
  eta = par[v:l]
  sigma1 = par[l+1]
  sigma2 = par[l+2]
  #rho = par[l+3]
  alp1 = par[l+3]
  
  transY = YJtrans(Y,alp1)
  DtransY = DYJtrans(Y,alp1)
  
  z1 = (transY-(M%*%beta))/sigma1
  z2 = (transY-(M%*%eta))/sigma2
  
  tot = ((1/sigma1)*dnorm(z1)*(1-pnorm(z2)))^Delta*((1/sigma2)*dnorm(z2)*(1-pnorm(z1)))^(1-Delta)*DtransY
  p1 = pmax(tot,1e-100)
  Logn = sum(log(p1)); 
  return(-Logn)
}





########################################
# Functions related to copula model-2019
#######################################


#Data simulations

#Data simulations

dat.sim.competitors = function(n,par,iseed,C){
  
  set.seed(iseed)
  beta = par[[1]]
  eta = par[[2]]
  sd = par[[3]]
  x0 = rep(1,n)
  x1 = rbinom(n,1,0.5)
  #x2= runif(n,-1,1)
  M = matrix(c(x0,x1),ncol=2,nrow=n)   # data matrix
  mu1 = M%*%beta
  mu2 = M%*%eta
  
  #From elliptical copulas
  
  if (C == 1)
  {
    norm.cop = normalCopula(c(sd[3]), dim = 2, dispstr = "un") # normal
    myMvd = mvdc(copula = norm.cop, margins= c("norm", "norm"),paramMargins=list(list(mean = mu1, sd = sd[1]),list(mean=mu2,sd=sd[2])))
    vect = rMvdc(n,myMvd);
    T1 = vect[,1]
    C = vect[,2]
    Y = pmin(T1,C)
    d1 = as.numeric(Y==T1)
    Y = IYJtrans(Y,sd[4])
    data = cbind(Y,d1,M)
  }
  else if (C==2){
    t.cop <- tCopula(c(sd[3]), dim = 2, dispstr = "un",df = sd[5], df.fixed = FALSE) #t-distr
    myMvd <- mvdc(copula = t.cop, margins= c("norm", "norm"),paramMargins=list(list(mean = mu1, sd = sd[1]),list(mean = mu2,sd = sd[2])))
    
    vect <- rMvdc(n,myMvd);
    T1 = vect[,1]
    C = vect[,2]
    Y = pmin(T1,C)
    d1 = as.numeric(Y==T1)
    Y = IYJtrans(Y,sd[4])
    data = cbind(Y,d1,M)
  }
  else if (C==3){ # Frank copulas
    #tau(frankCopula(6.5)), tau = 0.54, rho =0.75
    myCop <- frankCopula(param = 6.5,dim=2)
    myMvd = mvdc(copula = myCop, margins = c("norm", "norm"), paramMargins=list(list(mean = mu1, sd = sd[1]),list(mean=mu2,sd=sd[2])))
    
    vect <- rMvdc(n,myMvd);
    T1 = vect[,1]
    C = vect[,2]
    Y = pmin(T1,C)
    d1 = as.numeric(Y==T1)
    Y = IYJtrans(Y,sd[4])
    data = cbind(Y,d1,M)
  }
  else if (C==4){ # Gumbel copulas
    #tau(gumbelCopula(2.2)) #tau = 0.54; rho = 0.75
    myCop <- gumbelCopula(param = 2.2, dim = 2)
    myMvd = mvdc(copula = myCop, margins= c("norm", "norm"),paramMargins=list(list(mean = mu1, sd = sd[1]),list(mean=mu2,sd=sd[2])))
    
    vect <- rMvdc(n,myMvd);
    T1 = vect[,1]
    C = vect[,2]
    Y = pmin(T1,C)
    d1 = as.numeric(Y==T1)
    Y = IYJtrans(Y,sd[4])
    data = cbind(Y,d1,M)
  }
  else if (C==5){ # t-margins with normal copula
    norm.cop = normalCopula(c(sd[3]), dim = 2, dispstr = "un") # normal
    myMvd <- mvdc(copula = norm.cop, margins = c("t", "t"),paramMargins = list(list(df=sd[5]),list(df=sd[5])))
    vect <- rMvdc(n,myMvd);
    T1 = vect[,1]+mu1
    C = vect[,2]+mu2
    Y = pmin(T1,C)
    d1 = as.numeric(Y==T1)
    Y = IYJtrans(Y,sd[4])
    data = cbind(Y,d1,M)
  }  
  return(data)
}


NPMLE = function(par,G,init,SD,n,rho){
  temp = sum(1-pnorm((init-rho*qnorm(par))/(1-rho^2)^(0.5)))/n*(par-G)-SD/n
  return(temp)
}


Kden <- function(x,h,w){ #density estimaion
  n = length(x)
  xmat = matrix(x,n,n) - matrix(x,n,n,byrow=TRUE)
  
  K = dnorm(xmat/h)/h
  den =  K%*%w
  
  list(y=den)
}


# Functions for solving estimating equation

CGE = function(dat,beta,eta,rho1){
  dat1 = dat[order(dat[,2]),]
  Y.sort1 = dat1[,2]
  d.sort1 = dat1[,3]
  M = dat1[,4]
  W = M
  n = length(Y.sort1)
  
  F1 = rep(0,n)
  F1[1] = 0.001
  
  tryCatch({
    for (i in 2:n){
      j = i-1
      if(d.sort1[i]==1)
      {
        init1 = (Y.sort1[i]-(W*eta)+(M*beta))
        Subd = sum(Y.sort1==Y.sort1[i]& d.sort1[i]==1)
        
        F1[i] = uniroot(NPMLE,interval = c(0,1),G = F1[j],init = init1 ,SD = Subd,n=n,rho=rho1)$root
        #F1[i] = optim(0.2,NPMLE2,G = F1[j],init = init1 ,SD = Subd,n = n, rho=rho1,gr = NULL,method = "Brent",lower= 0,upper=1,control=c(trace=0))$par
      }
      else F1[i] = F1[j]
    }
  },error = function(e) ''
  )
  k1 = which(F1==max(F1))[1]
  F1[k1:n] = max(F1)
  
  dataT = cbind(dat1,F1)
  return(dataT)
}

#Likelihood functions;

LikProposed = function(par,Y,Delta,M){ #Joint model with dependent censoring
  k = 1
  l = 2*k
  v = k+1
  beta = par[1:k]
  eta = par[v:l]
  sigma1 = 1
  sigma2 = 1
  rho = par[l+1]
  alp1 = par[l+2]
  
  transY = YJtrans(Y,alp1)
  DtransY = DYJtrans(Y,alp1)
  
  z1 = (transY-(M*beta))/sigma1
  z2 = ((1-rho*sigma2/sigma1)*transY-(M*eta-rho*(sigma2/sigma1)*M*beta))/(sigma2*(1-rho^2)^0.5)
  z3 = (transY-(M*eta))/sigma2
  z4 = ((1-rho*sigma1/sigma2)*transY-(M*beta-rho*(sigma1/sigma2)*M*eta))/(sigma1*(1-rho^2)^0.5)
  tot = ((1/sigma1)*dnorm(z1)*(1-pnorm(z2)))^Delta*((1/sigma2)*dnorm(z3)*(1-pnorm(z4)))^(1-Delta)*DtransY
  p1 = pmax(tot,1e-100)
  Logn = sum(log(p1)); 
  return(-Logn)
}


#Copula model with unspecified marginal

LikCopula = function(par,Y,d,M,W,rho1){ #likelihood function
  k = 1
  l = 2*k
  v = k+1
  beta = par[1:k]
  eta = par[v:l]
  
  alp1 = par[l+1]
  m = length(Y)
  
  transY = YJtrans(Y,alp1)
  DtransY = DYJtrans(Y,alp1)
  
  # observed residuals
  
  R1 = (transY-(M*beta))
  R2 = (transY-(W*eta))
  D1 = d
  D2 = 1-d
  Id = 1:m
  
  dat1 = cbind(Id,R1,D1,M)
  dat2 = cbind(Id,R2,D2)
  
  
  Cd1 = CGE(dat1,beta,eta,rho1)  # Fit CGE 
  
  # Getting distributions
  
  out1 = Cd1  #First comp.
  F1 = out1[,5]
  F1 = replace(F1,F1==0,0.001);
  w1 = rep(0,m); w1[1] = F1[1]
  w1[2:m] = F1[2:m]-F1[1:(m-1)] 
  h1 = m^(-1/5)                 #bandwidth
  den1 = Kden(out1[,2],h=h1,w=w1)$y
  den1 = replace(den1,den1==0,0.001)
  out1 = cbind(out1,den1);
  
  #Re-arrenge the data
  
  outF = merge(out1,dat2,by="Id")
  d11 = outF[,3]; F11 = outF[,5]; den11 = outF[,6]
  d22 = outF[,8] ; R22 = outF[,7];
  
  
  #Compute Log-likelihood
  
  term1 = (1-pnorm((R22-rho1*qnorm(F11))/sqrt(1-rho1^2)))*den11;
  term2 = (1-pnorm((qnorm(F11)-rho1*R22)/sqrt(1-rho1^2)))*dnorm(R22);
  
  Logn = -sum(d11*log(pmax(term1,1e-10))+ d22*log(pmax(term2,1e-10))+log(DtransY));
  return(Logn)
}

# The end

